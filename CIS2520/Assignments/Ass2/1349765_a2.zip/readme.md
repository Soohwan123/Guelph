# CIS2520-F24-A2

## Student Information 
Name : Soohwan Kim

Student Number : 1349765

## Assignment Overview
What is the assignment about?  
Explain the purpose of the program and what it accomplishes.

First of all, q1 is about making a rental car program by using SinglyLinkedList and the list is for
storing data according to the purpose of the list. So the program holds three linkedlists represent
available car list, rented car list and repair car list respectively and the program is able to switch
cars from a list to a list by deletion and insertion of linkedlist. Lastly, whatever changes made, they 
are stored in text files.

Secondly, q2 is about Polish Notation calculator by implementing stack structure. When a polish Notation
equation is input, the program uses Stack to pop each character and determines if the char is integer
or an operand. After the determination, program calculates one by one and put the result back in the stack
until the stack holds only one value which is going to be the final result of the equation.

## Resources 
Did you use any resources (for example book, notes etc) in this assignment?

https://stackoverflow.com/questions/7021725/how-to-convert-a-string-to-integer-in-c
https://www.tutorialspoint.com/isalnum-function-in-c-language
https://sentry.io/answers/char-to-int-in-c-and-cpp/
https://www.cs.colby.edu/maxwell/courses/tutorials/maketutor/
https://stackoverflow.com/questions/21548464/how-to-write-a-makefile-to-compile-a-simple-c-program
https://makefiletutorial.com/

## Implementation
Is the assignment complete? If not, mention what part of the assignment is missing or incomplete.
It is complete. Although I added a data format validator function into the q1_functions and q1.h._
